<html>
<head>
<title>
Forgot Password
</title>
<link rel="stylesheet" href="../index.html_files/freemind2html.css" type="text/css"/>
</head>
<body>
<div style="text-align:center">
<a class="style3" href='index.php' style="text-align:center;"><img src="../images/Home.png" height='24'; width='24'></br>HOME</a>
</div>
<div style="text-align:center; margin-top:70px;">
<center>
<img src="../images/pass-forgot.jpg" width="900" height="132">
</center>
</div>
<div class="botton_fix">For more please visit : <a href="http://www.hiteshchoudhary.com" target="_blank">www.hiteshchoudhary.com</a></div>
</body>
</html>
